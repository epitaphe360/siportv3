<?php
/**
 * Plugin Name: SIPORTS Minimal
 * Plugin URI: https://siportevent.com
 * Description: Version minimale sans fonctionnalités
 * Version: 1.0.0
 * Author: SIPORTS Team
 * License: GPL v2 or later
 * Text Domain: siports-minimal
 */

// Ne rien faire d'autre, juste exister comme plugin
?>

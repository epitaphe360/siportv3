<?php
// Ce fichier est à placer à la racine de votre site WordPress pour tester votre installation PHP
// Nom du fichier: phpinfo.php

// Affiche toutes les informations sur PHP
phpinfo();
?>
